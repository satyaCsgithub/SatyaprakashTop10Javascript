﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SatyaprakashTop10Javascript.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Normal()
        {
            return View();
        }
        public ActionResult Bootbox()
        {
            return View();
        }
        public ActionResult toastr()
        {
            return View();
        }
        public ActionResult Notie()
        {
            return View();
        }
        public ActionResult iziToast()
        {
            return View();
        }
        public ActionResult VEX()
        {
            return View();
        }
        public ActionResult SweetAlert()
        {
            return View();
        }
        public ActionResult Alertify()
        {
            return View();
        }
        public ActionResult OhSnap()
        {
            return View();
        }
        public ActionResult NOTY()
        {
            return View();
        }
        public ActionResult AmaranJS()
        {
            return View();
        }
        public ActionResult Notific8()
        {
            return View();
        }
    }
}
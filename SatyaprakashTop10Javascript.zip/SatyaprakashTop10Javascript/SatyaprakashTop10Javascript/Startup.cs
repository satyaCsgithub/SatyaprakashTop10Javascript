﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SatyaprakashTop10Javascript.Startup))]
namespace SatyaprakashTop10Javascript
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
